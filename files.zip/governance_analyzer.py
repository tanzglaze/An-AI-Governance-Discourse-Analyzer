"""
AI Governance Discourse Analyzer
---------------------------------
Analyzes AI policy and governance texts to surface tone,
ethical concerns, and key themes using the Anthropic API.

Author: [Your Name]
Project: HyperQuark Research Fellowship Portfolio
"""

import json
import anthropic

client = anthropic.Anthropic()  # uses ANTHROPIC_API_KEY env variable


SAMPLE_TEXT = """
The European Union's Artificial Intelligence Act establishes a risk-based approach
to AI regulation, categorizing systems by their potential harm to fundamental rights.
High-risk AI systems must comply with stringent requirements around transparency,
human oversight, and data governance. The Act explicitly prohibits certain AI
applications deemed unacceptable risks, such as social scoring by governments
and real-time biometric surveillance in public spaces.
"""


def analyze_governance_text(text: str) -> dict:
    """
    Send policy text to Claude and return structured analysis.

    Args:
        text: Raw AI policy or governance text

    Returns:
        Dictionary with tone scores, themes, ethical concerns, and summary
    """
    prompt = f"""You are an AI governance and policy analyst.
Analyze the following text and return ONLY valid JSON with this structure:
{{
  "tone_scores": {{
    "precautionary": <0-100>,
    "rights_based": <0-100>,
    "techno_optimist": <0-100>,
    "security_focused": <0-100>,
    "equity_centered": <0-100>
  }},
  "sentiment_score": <-100 to 100>,
  "key_themes": [<4-6 short theme strings>],
  "ethical_concerns": [
    {{"title": <string>, "severity": "high|medium|low", "description": <string>}}
  ],
  "governance_approach": "regulatory|voluntary|international|technical|rights-based",
  "summary": <2-3 sentence analytical summary>
}}

Text to analyze:
{text}"""

    message = client.messages.create(
        model="claude-opus-4-5",
        max_tokens=1024,
        messages=[{"role": "user", "content": prompt}]
    )

    raw = message.content[0].text
    # Strip any accidental markdown fences
    clean = raw.replace("```json", "").replace("```", "").strip()
    return json.loads(clean)


def print_report(result: dict, source_label: str = "Text") -> None:
    """Pretty-print the analysis results to the terminal."""
    print(f"\n{'='*60}")
    print(f"  GOVERNANCE DISCOURSE ANALYSIS — {source_label.upper()}")
    print(f"{'='*60}\n")

    score = result.get("sentiment_score", 0)
    if score > 40:
        sentiment = "Optimistic"
    elif score > 10:
        sentiment = "Cautiously optimistic"
    elif score > -10:
        sentiment = "Neutral"
    elif score > -40:
        sentiment = "Cautionary"
    else:
        sentiment = "Alarmist"

    print(f"Sentiment:          {sentiment} (score: {score:+d})")
    print(f"Governance approach: {result.get('governance_approach', 'N/A')}\n")

    print("Discourse tone profile:")
    tone_labels = {
        "precautionary":   "Precautionary  ",
        "rights_based":    "Rights-based   ",
        "techno_optimist": "Techno-optimist",
        "security_focused":"Security-focused",
        "equity_centered": "Equity-centered "
    }
    for key, label in tone_labels.items():
        pct = result.get("tone_scores", {}).get(key, 0)
        bar = "█" * (pct // 5) + "░" * (20 - pct // 5)
        print(f"  {label}: {bar} {pct}%")

    print(f"\nKey themes:")
    for theme in result.get("key_themes", []):
        print(f"  • {theme}")

    print(f"\nEthical concerns flagged:")
    for concern in result.get("ethical_concerns", []):
        severity = concern.get("severity", "?").upper()
        title = concern.get("title", "")
        desc = concern.get("description", "")
        print(f"  [{severity}] {title}")
        print(f"        {desc}\n")

    print("Analytical summary:")
    print(f"  {result.get('summary', '')}\n")


def analyze_file(filepath: str) -> None:
    """Load a text file and analyze it."""
    with open(filepath, "r", encoding="utf-8") as f:
        text = f.read()
    result = analyze_governance_text(text)
    print_report(result, source_label=filepath)
    # Also save JSON output
    out_path = filepath.replace(".txt", "_analysis.json")
    with open(out_path, "w") as f:
        json.dump(result, f, indent=2)
    print(f"JSON saved to: {out_path}")


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1:
        # Usage: python governance_analyzer.py my_policy.txt
        analyze_file(sys.argv[1])
    else:
        # Run on the built-in sample
        print("No file provided — running on sample EU AI Act excerpt.\n")
        result = analyze_governance_text(SAMPLE_TEXT)
        print_report(result, source_label="EU AI Act (sample)")
        print("Tip: run with a .txt file path to analyze your own text.")
        print("     python governance_analyzer.py my_policy.txt")
